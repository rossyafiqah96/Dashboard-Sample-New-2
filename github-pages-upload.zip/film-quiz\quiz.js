// ── Quiz Data ──────────────────────────────────────────────────────────────
const questions = [
  {
    question: "What is the PRIMARY purpose of the pre-production phase in filmmaking?",
    options: [
      "To edit and colour-grade the footage",
      "To plan every aspect of the film before principal photography begins",
      "To distribute the film to cinemas and streaming platforms",
      "To record the film's musical score and sound effects"
    ],
    answer: 1,
    explanation: "Pre-production is the planning stage where scripts, budgets, schedules, cast, crew, and locations are finalised before any camera rolls."
  },
  {
    question: "A storyboard in pre-production is best described as:",
    options: [
      "A legal contract between the director and the studio",
      "A series of sequential illustrated panels that visualise each shot of the film",
      "A detailed list of all props and costumes required on set",
      "A financial document outlining the production budget"
    ],
    answer: 1,
    explanation: "A storyboard is a visual script — a sequence of drawn panels representing camera angles, movement, and composition for each planned shot."
  },
  {
    question: "Which document breaks down the screenplay into a day-by-day filming schedule and lists every scene, cast member, and resource needed each day?",
    options: [
      "The call sheet",
      "The shooting script",
      "The production breakdown sheet",
      "The treatment"
    ],
    answer: 2,
    explanation: "A production breakdown sheet (or strip board) organises every scene from the script into a shooting schedule, detailing cast, locations, and equipment needed per day."
  },
  {
    question: "What is the main goal of LOCATION SCOUTING during pre-production?",
    options: [
      "To audition and cast the lead actors for the film",
      "To negotiate distribution rights with streaming platforms",
      "To identify and evaluate real-world places that match the script's setting and are practical to film in",
      "To design and construct indoor studio sets for filming"
    ],
    answer: 2,
    explanation: "Location scouting involves visiting potential filming sites to assess their suitability — checking lighting, acoustics, permits, logistics, and how well they match the script's vision."
  },
  {
    question: "In film pre-production, a TREATMENT is:",
    options: [
      "A short prose document that describes the story, tone, and key scenes of a film before the full screenplay is written",
      "A medical waiver form signed by stunt performers before shooting action scenes",
      "A post-production colour-correction process applied to raw footage",
      "A union agreement between the director of photography and the production company"
    ],
    answer: 0,
    explanation: "A treatment is a written narrative overview of the film — usually 2–10 pages — outlining the story structure, characters, and tone. It is produced before writing the full screenplay."
  }
];

// ── State ──────────────────────────────────────────────────────────────────
let currentIndex = 0;
let score = 0;
let answered = false;
let userAnswers = [];

// ── DOM refs ───────────────────────────────────────────────────────────────
const progressFill    = document.getElementById("progress-fill");
const qCurrent        = document.getElementById("q-current");
const qTotal          = document.getElementById("q-total");
const questionNumber  = document.getElementById("question-number");
const questionText    = document.getElementById("question-text");
const optionsList     = document.getElementById("options-list");
const btnNext         = document.getElementById("btn-next");
const questionCard    = document.getElementById("question-card");
const resultCard      = document.getElementById("result-card");
const resultIcon      = document.getElementById("result-icon");
const resultScore     = document.getElementById("result-score");
const resultFeedback  = document.getElementById("result-feedback");
const resultBreakdown = document.getElementById("result-breakdown");
const btnRestart      = document.getElementById("btn-restart");

// ── Init ───────────────────────────────────────────────────────────────────
qTotal.textContent = questions.length;
loadQuestion(currentIndex);

// ── Functions ──────────────────────────────────────────────────────────────
function loadQuestion(index) {
  answered = false;
  btnNext.disabled = true;

  const q = questions[index];

  // Progress
  const pct = ((index) / questions.length) * 100;
  progressFill.style.width = pct + "%";
  qCurrent.textContent = index + 1;

  questionNumber.textContent = "Question " + (index + 1);
  questionText.textContent   = q.question;

  // Build options
  optionsList.innerHTML = "";
  q.options.forEach((opt, i) => {
    const li    = document.createElement("li");
    const label = document.createElement("label");
    const radio = document.createElement("input");

    radio.type  = "radio";
    radio.name  = "option";
    radio.value = i;

    label.appendChild(radio);
    label.appendChild(document.createTextNode(opt));
    li.appendChild(label);

    li.addEventListener("click", () => {
      if (answered) return;
      // Deselect all
      document.querySelectorAll("#options-list li").forEach(el => el.classList.remove("selected"));
      radio.checked = true;
      li.classList.add("selected");
      btnNext.disabled = false;
    });

    optionsList.appendChild(li);
  });

  // Update next button label
  btnNext.textContent = index === questions.length - 1 ? "Submit Quiz ✓" : "Next →";
}

// ── Next / Submit ──────────────────────────────────────────────────────────
btnNext.addEventListener("click", () => {
  if (answered) return;
  answered = true;

  const selected = document.querySelector('#options-list input[name="option"]:checked');
  if (!selected) return;

  const chosenIndex = parseInt(selected.value);
  const correct     = questions[currentIndex].answer;
  const items       = document.querySelectorAll("#options-list li");

  userAnswers.push({ chosen: chosenIndex, correct });

  // Highlight correct / wrong
  items.forEach((li, i) => {
    li.querySelectorAll("input").forEach(r => r.disabled = true);
    if (i === correct) {
      li.classList.add("correct");
    } else if (i === chosenIndex && chosenIndex !== correct) {
      li.classList.add("wrong");
    }
  });

  if (chosenIndex === correct) {
    score++;
    btnNext.textContent = currentIndex === questions.length - 1 ? "See Results ✓" : "Next →";
  } else {
    btnNext.textContent = currentIndex === questions.length - 1 ? "See Results ✓" : "Next →";
  }

  btnNext.disabled = false;

  // Auto-advance after short delay on non-last questions
  if (currentIndex < questions.length - 1) {
    setTimeout(() => {
      currentIndex++;
      loadQuestion(currentIndex);
      answered = false;
    }, 900);
    btnNext.disabled = true; // prevent double click during delay
  } else {
    btnNext.textContent = "See Results ✓";
    btnNext.disabled = false;
    btnNext.onclick = showResults;
  }
});

// ── Show Results ───────────────────────────────────────────────────────────
function showResults() {
  // Full progress
  progressFill.style.width = "100%";
  qCurrent.textContent = questions.length;

  questionCard.classList.add("hidden");
  resultCard.classList.remove("hidden");

  // Icon & feedback
  let icon, feedback;
  if (score === 5) {
    icon     = "🏆";
    feedback = "Outstanding! Perfect score! You have an excellent grasp of film pre-production. You're ready to step onto any film set with confidence.";
  } else if (score >= 4) {
    icon     = "🌟";
    feedback = "Great work! You clearly understand most pre-production concepts. Review the one you missed and you'll be fully prepared.";
  } else if (score >= 3) {
    icon     = "👍";
    feedback = "Good effort! You have a solid foundation. Revisit the topics you missed — particularly storyboarding, breakdowns, and treatments.";
  } else if (score >= 2) {
    icon     = "📚";
    feedback = "Keep studying! You got some right, but pre-production is a critical phase. Review your notes on scripts, breakdowns, and planning documents.";
  } else {
    icon     = "🎬";
    feedback = "Don't give up! Pre-production can be tricky. Head back to your textbook, focus on the planning documents and their purposes, then try again.";
  }

  resultIcon.textContent    = icon;
  resultScore.textContent   = `Your Score: ${score} / ${questions.length}`;
  resultFeedback.textContent = feedback;

  // Breakdown
  resultBreakdown.innerHTML = "";
  userAnswers.forEach((ans, i) => {
    const isCorrect = ans.chosen === ans.correct;
    const div = document.createElement("div");
    div.className = "breakdown-item";
    div.innerHTML = `
      <span class="breakdown-icon">${isCorrect ? "✅" : "❌"}</span>
      <div>
        <strong>Q${i + 1}:</strong> ${questions[i].question.substring(0, 60)}…<br>
        <span style="color:#57606a;font-size:12px;">${questions[i].explanation}</span>
      </div>
    `;
    resultBreakdown.appendChild(div);
  });
}

// ── Restart ────────────────────────────────────────────────────────────────
btnRestart.addEventListener("click", () => {
  currentIndex = 0;
  score        = 0;
  answered     = false;
  userAnswers  = [];

  resultCard.classList.add("hidden");
  questionCard.classList.remove("hidden");

  // Reset next button listener
  btnNext.onclick = null;

  loadQuestion(0);
});
