// ═══════════════════════════════════════════════════════════════
//  TVET Student Task Dashboard — dashboard.js  (v4)
//  New features: notification badge, remarks search, bulk update,
//  due date + auto-overdue, row colour by status, daily summary
//  banner, undo last change, column visibility, avatar initials,
//  import CSV, class tabs, sticky note
// ═══════════════════════════════════════════════════════════════

// ─── Avatar colour palette ─────────────────────────────────────
const AVATAR_COLOURS = ["#2563eb","#16a34a","#ea580c","#7c3aed","#0891b2","#be185d","#065f46","#92400e"];
function avatarColour(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffffffff;
  return AVATAR_COLOURS[Math.abs(h) % AVATAR_COLOURS.length];
}
function initials(name) {
  const parts = name.trim().split(" ");
  return (parts[0][0] + (parts[1] ? parts[1][0] : "")).toUpperCase();
}

// ─── Default data ──────────────────────────────────────────────
const FUTURE_DATE = (() => {
  const d = new Date(); d.setDate(d.getDate() + 14);
  return d.toISOString().slice(0, 10);
})();
const PAST_DATE   = "2025-05-01";

const DEFAULT_STUDENTS = [
  { id:"DV2501", name:"Ahmad Farouk bin Zulkifli",    cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2502", name:"Nur Aisyah binti Ramlan",      cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2503", name:"Muhammad Haziq bin Roslan",    cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2504", name:"Siti Norfadzillah binti Aziz", cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2505", name:"Khairul Anwar bin Hamid",      cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2506", name:"Nurul Hidayah binti Sulaiman", cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2507", name:"Firdaus bin Othman",           cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2508", name:"Amirah binti Kamarudin",       cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2509", name:"Zulhilmi bin Ismail",          cls:"DVP1A", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2510", name:"Nadhirah binti Mohd Noor",     cls:"DVP1A", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2511", name:"Syafiq bin Abd Ghani",         cls:"DVP1B", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2512", name:"Liyana binti Hashim",          cls:"DVP1B", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2513", name:"Irfan bin Mohd Salleh",        cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2514", name:"Zahirah binti Yusof",          cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2515", name:"Hafizuddin bin Baharom",       cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2516", name:"Nabilah binti Ahmad",          cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2517", name:"Afiq Danial bin Mansor",       cls:"DVP1B", assignment:"Location Scouting Report",   dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2518", name:"Farhana binti Zain",           cls:"DVP1B", assignment:"Location Scouting Report",   dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2519", name:"Hakim bin Sahari",             cls:"DVP1B", assignment:"Location Scouting Report",   dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2520", name:"Syazwani binti Razak",         cls:"DVP1B", assignment:"Location Scouting Report",   dueDate:FUTURE_DATE, status:"Completed", remarks:"",                            updatedAt:null },
  { id:"DV2521", name:"Ridhwan bin Mohd Ariff",       cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Pending",   remarks:"",                            updatedAt:null },
  { id:"DV2522", name:"Qistina binti Shafie",         cls:"DVP1A", assignment:"Script Writing",             dueDate:FUTURE_DATE, status:"Pending",   remarks:"",                            updatedAt:null },
  { id:"DV2523", name:"Azriel bin Abdullah",          cls:"DVP1A", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Pending",   remarks:"Requested extension",         updatedAt:null },
  { id:"DV2524", name:"Insyirah binti Kasim",         cls:"DVP1B", assignment:"Storyboard Development",     dueDate:FUTURE_DATE, status:"Pending",   remarks:"",                            updatedAt:null },
  { id:"DV2525", name:"Danial Arif bin Jusoh",        cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Pending",   remarks:"",                            updatedAt:null },
  { id:"DV2526", name:"Maisarah binti Zainudin",      cls:"DVP1B", assignment:"Pre-Production Planning",    dueDate:FUTURE_DATE, status:"Pending",   remarks:"Medical leave",               updatedAt:null },
  { id:"DV2527", name:"Izzuddin bin Halim",           cls:"DVP1A", assignment:"Location Scouting Report",   dueDate:PAST_DATE,   status:"Overdue",   remarks:"No response from student",    updatedAt:null },
  { id:"DV2528", name:"Batrisyia binti Lokman",       cls:"DVP1B", assignment:"Location Scouting Report",   dueDate:PAST_DATE,   status:"Overdue",   remarks:"",                            updatedAt:null },
];

// ─── Storage keys ───────────────────────────────────────────────
const KEY_STUDENTS   = "tvet_students_v4";
const KEY_CHECKLIST  = "tvet_checklist";
const KEY_DARK       = "tvet_dark";
const KEY_NOTE       = "tvet_note";
const KEY_COLS       = "tvet_cols";
const KEY_DAILY      = "tvet_daily";
const CHECKLIST_KEYS = ["cl-1","cl-2","cl-3","cl-4"];
const PAGE_SIZE      = 10;
const PENDING_WARN   = 5; // show badge if pending > this

// ─── State ──────────────────────────────────────────────────────
let students         = [];
let sortCol          = "name";
let sortDir          = "asc";
let currentPage      = 1;
let editingIdx       = -1;
let pendingConfirmCb = null;
let undoStack        = [];        // {students, msg}
let selectedClass    = "ALL";
let hiddenCols       = new Set(); // column names to hide
let selectedRows     = new Set(); // real indices
let dailyChanges     = 0;

// ─── Load/save students ─────────────────────────────────────────
function loadStudents() {
  try { const s = localStorage.getItem(KEY_STUDENTS); if (s) return JSON.parse(s); } catch(e){}
  return DEFAULT_STUDENTS.map(s => ({...s}));
}
function saveStudents() {
  try { localStorage.setItem(KEY_STUDENTS, JSON.stringify(students)); } catch(e){}
}
students = loadStudents();

// ─── Load/save daily change count ───────────────────────────────
function loadDailyChanges() {
  try {
    const today = new Date().toISOString().slice(0,10);
    const d = JSON.parse(localStorage.getItem(KEY_DAILY)||"{}");
    return d.date === today ? (d.count||0) : 0;
  } catch(e){ return 0; }
}
function saveDailyChanges() {
  try {
    const today = new Date().toISOString().slice(0,10);
    localStorage.setItem(KEY_DAILY, JSON.stringify({date:today, count:dailyChanges}));
  } catch(e){}
}
dailyChanges = loadDailyChanges();

// ─── DOM refs ────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const cardTotal        = $("card-total");
const cardCompleted    = $("card-completed");
const cardPending      = $("card-pending");
const cardCompletedBar = $("card-completed-bar");
const cardPendingBar   = $("card-pending-bar");
const cardCompletedPct = $("card-completed-pct");
const cardPendingPct   = $("card-pending-pct");
const notifBadge       = $("notif-badge");
const checklistProgress= $("checklist-progress");
const checklistBarFill = $("checklist-bar-fill");
const checklistEl      = $("checklist");
const btnResetChecklist= $("btn-reset-checklist");
const tableBody        = $("table-body");
const searchInput      = $("search-input");
const filterStatus     = $("filter-status");
const filterAssignment = $("filter-assignment");
const btnClearFilters  = $("btn-clear-filters");
const navDate          = $("nav-date");
const darkToggle       = $("dark-toggle");
const btnExportCsv     = $("btn-export-csv");
const btnPrint         = $("btn-print");
const toast            = $("toast");
const tableRecordCount = $("table-record-count");
const pgInfo           = $("pg-info");
const pgControls       = $("pg-controls");
const assignStatsGrid  = $("assign-stats-grid");
const summaryBanner    = $("summary-banner");
const stickyNote       = $("sticky-note");
const colToggleRow     = $("col-toggle-row");
const bulkBar          = $("bulk-bar");
const bulkCount        = $("bulk-count");
const bulkStatusSel    = $("bulk-status-select");
const btnBulkApply     = $("btn-bulk-apply");
const btnBulkCancel    = $("btn-bulk-cancel");
const chkAll           = $("chk-all");
const modalStudent     = $("modal-student");
const modalStudentTitle= $("modal-student-title");
const fStuId           = $("f-stu-id");
const fStuName         = $("f-stu-name");
const fStuClass        = $("f-stu-class");
const fStuAssignment   = $("f-stu-assignment");
const fStuDuedate      = $("f-stu-duedate");
const fStuStatus       = $("f-stu-status");
const fStuRemarks      = $("f-stu-remarks");
const btnSaveStudent   = $("btn-save-student");
const btnAddStudent    = $("btn-add-student");
const modalConfirm     = $("modal-confirm");
const confirmTitle     = $("confirm-title");
const confirmMsg       = $("confirm-msg");
const btnConfirmOk     = $("btn-confirm-ok");

// ─── Date ────────────────────────────────────────────────────────
navDate.textContent = new Date().toLocaleDateString("en-MY", {
  weekday:"long", year:"numeric", month:"long", day:"numeric"
});

// ─── Dark mode ───────────────────────────────────────────────────
function applyDark(on) {
  document.body.classList.toggle("dark", on);
  darkToggle.textContent = on ? "☀️ Light" : "🌙 Dark";
}
applyDark(localStorage.getItem(KEY_DARK) === "true");
darkToggle.addEventListener("click", () => {
  const isDark = document.body.classList.contains("dark");
  applyDark(!isDark);
  try { localStorage.setItem(KEY_DARK, String(!isDark)); } catch(e){}
});

// ─── Toast with optional undo ─────────────────────────────────────
let toastTimer = null;
function showToast(msg, type="", canUndo=false) {
  toast.innerHTML = `<span>${msg}</span>`;
  if (canUndo && undoStack.length) {
    const btn = document.createElement("button");
    btn.className   = "undo-btn";
    btn.textContent = "Undo";
    btn.addEventListener("click", () => {
      const snap = undoStack.pop();
      if (snap) {
        students = snap.students;
        saveStudents();
        refreshAll();
        showToast("Action undone.", "success");
      }
    });
    toast.appendChild(btn);
  }
  toast.className = "toast" + (type ? " toast-" + type : "");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.className = "toast toast-hidden"; }, 4000);
}

// ─── Summary banner ──────────────────────────────────────────────
function updateBanner() {
  const done  = CHECKLIST_KEYS.filter(k => checklistEl.querySelector(`li[data-key="${k}"]`).classList.contains("cl-done")).length;
  const total = CHECKLIST_KEYS.length;
  summaryBanner.textContent =
    `📅 Today — ${dailyChanges} status update${dailyChanges!==1?"s":""} made  ·  ` +
    `Checklist ${done}/${total} completed  ·  ` +
    `${students.filter(s=>s.status==="Pending").length} pending  ·  ` +
    `${students.filter(s=>s.status==="Overdue").length} overdue`;
}

// ─── Cards ───────────────────────────────────────────────────────
function updateCards() {
  const visible  = selectedClass==="ALL" ? students : students.filter(s=>s.cls===selectedClass);
  const total    = visible.length;
  const comp     = visible.filter(s=>s.status==="Completed").length;
  const pend     = visible.filter(s=>s.status==="Pending"||s.status==="Overdue").length;
  const pctComp  = total>0 ? Math.round(comp/total*100) : 0;
  const pctPend  = total>0 ? Math.round(pend/total*100) : 0;

  cardTotal.textContent     = total;
  cardCompleted.textContent = comp;
  cardPending.textContent   = pend;
  cardCompletedBar.style.width = pctComp+"%";
  cardPendingBar.style.width   = pctPend+"%";
  cardCompletedPct.textContent = pctComp+"% completion rate";
  cardPendingPct.textContent   = pctPend+"% pending / overdue";

  // Notification badge (#1)
  const overallPend = students.filter(s=>s.status==="Pending"||s.status==="Overdue").length;
  notifBadge.classList.toggle("hidden", overallPend <= PENDING_WARN);

  [cardCompleted, cardPending].forEach(el => {
    el.style.transform = "scale(1.12)"; el.style.transition = "transform .18s";
    setTimeout(()=>{ el.style.transform="scale(1)"; }, 180);
  });
}

// ─── Assignment stats ─────────────────────────────────────────────
function updateAssignStats() {
  const src = selectedClass==="ALL" ? students : students.filter(s=>s.cls===selectedClass);
  const map = {};
  src.forEach(s => {
    if (!map[s.assignment]) map[s.assignment] = {total:0,done:0};
    map[s.assignment].total++;
    if (s.status==="Completed") map[s.assignment].done++;
  });
  assignStatsGrid.innerHTML = "";
  Object.keys(map).sort().forEach(title => {
    const {total,done} = map[title];
    const pct = total>0 ? Math.round(done/total*100) : 0;
    const d = document.createElement("div");
    d.className="assign-stat-card";
    d.innerHTML=`<div class="assign-stat-title" title="${title}">${title}</div>
      <div class="assign-stat-meta">${done}/${total} completed · ${pct}%</div>
      <div class="assign-stat-bar-wrap"><div class="assign-stat-bar" style="width:${pct}%"></div></div>`;
    assignStatsGrid.appendChild(d);
  });
}

// ─── Populate assignment filter ───────────────────────────────────
function populateAssignmentFilter() {
  const cur = filterAssignment.value;
  const titles = [...new Set(students.map(s=>s.assignment))].sort();
  filterAssignment.innerHTML = '<option value="">All Assignments</option>';
  titles.forEach(t=>{
    const o=document.createElement("option");
    o.value=t; o.textContent=t;
    if (t===cur) o.selected=true;
    filterAssignment.appendChild(o);
  });
}

// ─── Column visibility (#8) ──────────────────────────────────────
const COL_DEFS = [
  {key:"class",    label:"Class"},
  {key:"dueDate",  label:"Due Date"},
  {key:"remarks",  label:"Remarks"},
  {key:"updatedAt",label:"Last Updated"},
];

function loadHiddenCols() {
  try {
    const s = localStorage.getItem(KEY_COLS);
    if (s) return new Set(JSON.parse(s));
  } catch(e){}
  return new Set();
}
function saveHiddenCols() {
  try { localStorage.setItem(KEY_COLS, JSON.stringify([...hiddenCols])); } catch(e){}
}
hiddenCols = loadHiddenCols();

function buildColToggles() {
  colToggleRow.innerHTML = '<span style="font-size:12px;color:var(--muted);margin-right:4px;">Columns:</span>';
  COL_DEFS.forEach(col => {
    const btn = document.createElement("button");
    btn.className = "col-toggle-btn" + (hiddenCols.has(col.key) ? "" : " active");
    btn.textContent = col.label;
    btn.dataset.col = col.key;
    btn.addEventListener("click", () => {
      if (hiddenCols.has(col.key)) hiddenCols.delete(col.key);
      else hiddenCols.add(col.key);
      btn.classList.toggle("active");
      saveHiddenCols();
      applyColVisibility();
    });
    colToggleRow.appendChild(btn);
  });
}

function applyColVisibility() {
  document.querySelectorAll("[data-colname]").forEach(el => {
    const col = el.dataset.colname;
    if (col) el.classList.toggle("col-hidden", hiddenCols.has(col));
  });
  // tbody cells by position mapping
  const colOrder = ["class","assignment","dueDate","status","remarks","updatedAt"];
  // apply via header th data-colname and td data-colname
}

// ─── Due date display helper ──────────────────────────────────────
function dueDateDisplay(dateStr) {
  if (!dateStr) return `<span class="due-none">—</span>`;
  const today = new Date(); today.setHours(0,0,0,0);
  const due   = new Date(dateStr);
  const diff  = Math.round((due - today) / 86400000);
  const fmt   = due.toLocaleDateString("en-MY",{day:"2-digit",month:"short",year:"numeric"});
  if (diff < 0)      return `<span class="due-cell due-late">⚠ ${fmt} (${Math.abs(diff)}d ago)</span>`;
  if (diff === 0)    return `<span class="due-cell due-warn">Today</span>`;
  if (diff <= 3)     return `<span class="due-cell due-warn">${fmt} (${diff}d left)</span>`;
  return `<span class="due-cell due-ok">${fmt} (${diff}d left)</span>`;
}

// ─── Auto-overdue check ───────────────────────────────────────────
function autoCheckOverdue() {
  const today = new Date(); today.setHours(0,0,0,0);
  let changed = false;
  students.forEach(s => {
    if (s.dueDate && s.status === "Pending") {
      const due = new Date(s.dueDate);
      if (due < today) { s.status = "Overdue"; changed = true; }
    }
  });
  if (changed) saveStudents();
}

// ─── Filtering & sorting ──────────────────────────────────────────
function getFiltered() {
  const term   = searchInput.value.toLowerCase().trim();
  const status = filterStatus.value;
  const assign = filterAssignment.value;
  return students.filter(s => {
    if (selectedClass !== "ALL" && s.cls !== selectedClass) return false;
    const matchSearch = !term ||
      s.id.toLowerCase().includes(term) ||
      s.name.toLowerCase().includes(term) ||
      (s.remarks||"").toLowerCase().includes(term); // #2 search remarks
    const matchStatus = !status || s.status === status;
    const matchAssign = !assign || s.assignment === assign;
    return matchSearch && matchStatus && matchAssign;
  });
}
function getSorted(list) {
  return [...list].sort((a,b) => {
    const va = (a[sortCol]||"").toString().toLowerCase();
    const vb = (b[sortCol]||"").toString().toLowerCase();
    if (va<vb) return sortDir==="asc"?-1:1;
    if (va>vb) return sortDir==="asc"?1:-1;
    return 0;
  });
}

// ─── Highlight ───────────────────────────────────────────────────
function hl(text, term) {
  if (!term) return escHtml(text);
  const safe = escHtml(text);
  const re   = term.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  return safe.replace(new RegExp(`(${re})`,"gi"),"<mark class='hl'>$1</mark>");
}
function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

// ─── Timestamp ───────────────────────────────────────────────────
function fmtTs(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("en-MY",{day:"2-digit",month:"short",year:"numeric"})+
    ", "+d.toLocaleTimeString("en-MY",{hour:"2-digit",minute:"2-digit"});
}

// ─── Render table ────────────────────────────────────────────────
function renderTable() {
  const term    = searchInput.value.trim();
  const filtered= getFiltered();
  const sorted  = getSorted(filtered);
  const total   = sorted.length;
  const totalAll= (selectedClass==="ALL"?students:students.filter(s=>s.cls===selectedClass)).length;
  const pages   = Math.max(1,Math.ceil(total/PAGE_SIZE));

  if (currentPage>pages) currentPage=1;
  const start = (currentPage-1)*PAGE_SIZE;
  const slice = sorted.slice(start,start+PAGE_SIZE);

  tableRecordCount.textContent =
    total===totalAll ? `Showing ${total} students` : `Showing ${total} of ${totalAll} students (filtered)`;

  tableBody.innerHTML = "";

  if (!slice.length) {
    tableBody.innerHTML=`<tr><td colspan="12" style="text-align:center;padding:32px;color:var(--muted);font-style:italic;">No records match the selected filters.</td></tr>`;
  } else {
    slice.forEach((s,i) => {
      const ri       = students.indexOf(s);
      const rowNum   = start+i+1;
      const bc       = s.status.toLowerCase();
      const hlName   = hl(s.name,term);
      const hlId     = hl(s.id,term);
      const hlAssign = hl(s.assignment,term);
      const hlRem    = s.remarks ? hl(s.remarks,term) : "";
      const col      = avatarColour(s.name);
      const ini      = initials(s.name);
      const chkd     = selectedRows.has(ri) ? "checked" : "";
      const tr       = document.createElement("tr");
      tr.className   = `row-${bc}`;
      tr.innerHTML = `
        <td><input type="checkbox" class="row-chk" data-index="${ri}" ${chkd}/></td>
        <td class="row-num">${rowNum}</td>
        <td><span style="font-family:monospace;font-size:12.5px;color:var(--muted);">${hlId}</span></td>
        <td style="font-weight:600;white-space:nowrap;">
          <span class="avatar" style="background:${col}">${ini}</span>${hlName}
        </td>
        <td data-colname="class">${s.cls}</td>
        <td style="color:var(--muted);">${hlAssign}</td>
        <td data-colname="dueDate">${dueDateDisplay(s.dueDate)}</td>
        <td>
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
            <span class="badge badge-${bc}">${s.status}</span>
            <select class="status-select" data-index="${ri}">
              <option value="Completed" ${s.status==="Completed"?"selected":""}>Completed</option>
              <option value="Pending"   ${s.status==="Pending"  ?"selected":""}>Pending</option>
              <option value="Overdue"   ${s.status==="Overdue"  ?"selected":""}>Overdue</option>
            </select>
          </div>
        </td>
        <td class="remarks-cell" data-colname="remarks">
          ${s.remarks
            ? `<span class="remarks-text" title="${escHtml(s.remarks)}">${hlRem}</span>`
            : `<span class="remarks-empty">—</span>`}
        </td>
        <td class="last-updated" data-colname="updatedAt">${fmtTs(s.updatedAt)}</td>
        <td>
          <button class="btn-icon" data-action="edit"   data-index="${ri}" title="Edit">✏️</button>
          <button class="btn-icon" data-action="delete" data-index="${ri}" title="Delete">🗑️</button>
        </td>
      `;
      tableBody.appendChild(tr);
    });

    // Status change
    tableBody.querySelectorAll(".status-select").forEach(sel => {
      sel.addEventListener("change", e => {
        const idx = parseInt(e.target.dataset.index);
        pushUndo();
        students[idx].status    = e.target.value;
        students[idx].updatedAt = new Date().toISOString();
        dailyChanges++;
        saveDailyChanges();
        saveStudents();
        refreshAll();
        showToast(`${students[idx].name.split(" ")[0]} → ${students[idx].status}`, "success", true);
      });
    });

    // Row checkboxes (#3 bulk)
    tableBody.querySelectorAll(".row-chk").forEach(chk => {
      chk.addEventListener("change", e => {
        const idx = parseInt(e.target.dataset.index);
        if (e.target.checked) selectedRows.add(idx);
        else selectedRows.delete(idx);
        updateBulkBar();
      });
    });

    // Edit / Delete
    tableBody.querySelectorAll(".btn-icon").forEach(btn => {
      btn.addEventListener("click", () => {
        const action = btn.dataset.action;
        const idx    = parseInt(btn.dataset.index);
        if (action==="edit")   openEditModal(idx);
        if (action==="delete") confirmDelete(idx);
      });
    });
  }

  // Sync select-all
  const allVisible = slice.map(s=>students.indexOf(s));
  chkAll.checked = allVisible.length > 0 && allVisible.every(i=>selectedRows.has(i));
  chkAll.indeterminate = !chkAll.checked && allVisible.some(i=>selectedRows.has(i));

  renderPagination(pages, total, start, slice.length);

  // Sort icons
  document.querySelectorAll(".student-table th.sortable").forEach(th => {
    th.classList.remove("sort-asc","sort-desc");
    if (th.dataset.col===sortCol) th.classList.add(sortDir==="asc"?"sort-asc":"sort-desc");
  });

  applyColVisibility();
}

// ─── Select all ──────────────────────────────────────────────────
chkAll.addEventListener("change", () => {
  const filtered = getSorted(getFiltered());
  const slice    = filtered.slice((currentPage-1)*PAGE_SIZE, currentPage*PAGE_SIZE);
  slice.forEach(s => {
    const idx = students.indexOf(s);
    if (chkAll.checked) selectedRows.add(idx);
    else selectedRows.delete(idx);
  });
  updateBulkBar();
  renderTable();
});

// ─── Bulk bar (#3) ───────────────────────────────────────────────
function updateBulkBar() {
  bulkBar.classList.toggle("hidden", selectedRows.size === 0);
  bulkCount.textContent = `${selectedRows.size} selected`;
}

btnBulkApply.addEventListener("click", () => {
  const newStatus = bulkStatusSel.value;
  if (!newStatus || !selectedRows.size) return;
  pushUndo();
  const now = new Date().toISOString();
  selectedRows.forEach(idx => {
    students[idx].status    = newStatus;
    students[idx].updatedAt = now;
    dailyChanges++;
  });
  saveDailyChanges();
  saveStudents();
  const n = selectedRows.size;
  selectedRows.clear();
  bulkStatusSel.value = "";
  refreshAll();
  showToast(`${n} records updated to "${newStatus}".`, "success", true);
});

btnBulkCancel.addEventListener("click", () => {
  selectedRows.clear();
  bulkStatusSel.value = "";
  updateBulkBar();
  renderTable();
});

// ─── Pagination ───────────────────────────────────────────────────
function renderPagination(pages, total, start, count) {
  pgInfo.textContent = total===0 ? "" :
    `Page ${currentPage} of ${pages} · Records ${start+1}–${start+count} of ${total}`;
  pgControls.innerHTML = "";
  const addBtn = (label, pg, disabled, active) => {
    const b = document.createElement("button");
    b.className = "pg-btn"+(active?" active":"");
    b.textContent = label; b.disabled = disabled;
    b.addEventListener("click", ()=>{ currentPage=pg; renderTable(); });
    pgControls.appendChild(b);
  };
  addBtn("« Prev", currentPage-1, currentPage===1, false);
  for (let p=1; p<=pages; p++) {
    if (pages>7 && Math.abs(p-currentPage)>2 && p!==1 && p!==pages) {
      if (p===2||p===pages-1) { const sp=document.createElement("span"); sp.textContent="…"; sp.style.cssText="padding:5px 4px;color:var(--muted)"; pgControls.appendChild(sp); }
      continue;
    }
    addBtn(p, p, false, p===currentPage);
  }
  addBtn("Next »", currentPage+1, currentPage===pages, false);
}

// ─── Sort ─────────────────────────────────────────────────────────
document.querySelectorAll(".student-table th.sortable").forEach(th => {
  th.addEventListener("click", () => {
    const col = th.dataset.col;
    sortDir = sortCol===col ? (sortDir==="asc"?"desc":"asc") : "asc";
    sortCol = col; currentPage=1; renderTable();
  });
});

// ─── Class tabs ──────────────────────────────────────────────────
document.querySelectorAll(".class-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".class-tab").forEach(t=>t.classList.remove("active"));
    tab.classList.add("active");
    selectedClass = tab.dataset.class;
    currentPage = 1;
    selectedRows.clear();
    refreshAll();
  });
});

// ─── Add/Edit modal ───────────────────────────────────────────────
function openAddModal() {
  editingIdx=-1;
  modalStudentTitle.textContent="Add New Student";
  fStuId.value=""; fStuName.value=""; fStuAssignment.value="";
  fStuDuedate.value=""; fStuStatus.value="Pending"; fStuRemarks.value="";
  fStuClass.value="DVP1A"; fStuId.removeAttribute("readonly");
  clearFormErrors(); modalStudent.classList.remove("hidden"); fStuId.focus();
}
function openEditModal(idx) {
  editingIdx=idx;
  const s=students[idx];
  modalStudentTitle.textContent="Edit Student";
  fStuId.value=s.id; fStuName.value=s.name; fStuClass.value=s.cls;
  fStuAssignment.value=s.assignment; fStuDuedate.value=s.dueDate||"";
  fStuStatus.value=s.status; fStuRemarks.value=s.remarks||"";
  fStuId.setAttribute("readonly",true);
  clearFormErrors(); modalStudent.classList.remove("hidden"); fStuName.focus();
}
function closeStudentModal() { modalStudent.classList.add("hidden"); }

function clearFormErrors() {
  [fStuId,fStuName,fStuAssignment].forEach(el=>{
    el.classList.remove("error");
    el.parentElement.querySelector(".form-error")?.remove();
  });
}
function setFieldError(el,msg) {
  el.classList.add("error");
  let e=el.parentElement.querySelector(".form-error");
  if (!e) { e=document.createElement("span"); e.className="form-error"; el.parentElement.appendChild(e); }
  e.textContent=msg;
}

btnAddStudent.addEventListener("click", openAddModal);
$("modal-close-student").addEventListener("click", closeStudentModal);
$("modal-cancel-student").addEventListener("click", closeStudentModal);

btnSaveStudent.addEventListener("click", () => {
  clearFormErrors();
  const id=fStuId.value.trim(), name=fStuName.value.trim(), assign=fStuAssignment.value.trim();
  const status=fStuStatus.value, remarks=fStuRemarks.value.trim();
  const cls=fStuClass.value, dueDate=fStuDuedate.value||"";
  let valid=true;
  if (!id)     { setFieldError(fStuId,"Student ID is required.");    valid=false; }
  if (!name)   { setFieldError(fStuName,"Name is required.");        valid=false; }
  if (!assign) { setFieldError(fStuAssignment,"Assignment required."); valid=false; }
  if (valid && editingIdx===-1) {
    if (students.find(s=>s.id.toLowerCase()===id.toLowerCase()))
      { setFieldError(fStuId,"ID already exists."); valid=false; }
  }
  if (!valid) return;
  pushUndo();
  const now=new Date().toISOString();
  if (editingIdx===-1) {
    students.push({id,name,cls,assignment:assign,dueDate,status,remarks,updatedAt:now});
    showToast(`${name} added.`, "success");
  } else {
    students[editingIdx]={...students[editingIdx],name,cls,assignment:assign,dueDate,status,remarks,updatedAt:now};
    showToast(`${name} updated.`, "success");
  }
  saveStudents(); populateAssignmentFilter(); currentPage=1; refreshAll(); closeStudentModal();
});

// ─── Delete ───────────────────────────────────────────────────────
function confirmDelete(idx) {
  const s=students[idx];
  openConfirm("Delete Student",
    `Delete <strong>${escHtml(s.name)}</strong> (${escHtml(s.id)})? This cannot be undone.`,
    ()=>{
      pushUndo();
      students.splice(idx,1);
      saveStudents(); populateAssignmentFilter(); currentPage=1; refreshAll();
      showToast(`${s.name.split(" ")[0]} deleted.`, "", true);
    });
}

// ─── Undo ─────────────────────────────────────────────────────────
function pushUndo() {
  undoStack.push({ students: students.map(s=>({...s})) });
  if (undoStack.length > 10) undoStack.shift();
}

// ─── Confirm modal ────────────────────────────────────────────────
function openConfirm(title, msg, onOk) {
  confirmTitle.textContent=title; confirmMsg.innerHTML=msg;
  pendingConfirmCb=onOk; modalConfirm.classList.remove("hidden");
}
function closeConfirm() { modalConfirm.classList.add("hidden"); pendingConfirmCb=null; }

$("modal-close-confirm").addEventListener("click", closeConfirm);
$("modal-cancel-confirm").addEventListener("click", closeConfirm);
btnConfirmOk.addEventListener("click", ()=>{ if(pendingConfirmCb) pendingConfirmCb(); closeConfirm(); });

[modalStudent,modalConfirm].forEach(overlay=>{
  overlay.addEventListener("click", e=>{ if(e.target===overlay){ overlay.classList.add("hidden"); pendingConfirmCb=null; } });
});

// ─── Checklist ────────────────────────────────────────────────────
function loadChecklist() {
  try {
    const saved=JSON.parse(localStorage.getItem(KEY_CHECKLIST)||"{}");
    CHECKLIST_KEYS.forEach(k=>{
      const li=checklistEl.querySelector(`li[data-key="${k}"]`);
      if (saved[k]) li.classList.add("cl-done");
    });
  } catch(e){}
  updateChecklistProgress();
}
function saveChecklist() {
  const st={};
  CHECKLIST_KEYS.forEach(k=>{ st[k]=checklistEl.querySelector(`li[data-key="${k}"]`).classList.contains("cl-done"); });
  try { localStorage.setItem(KEY_CHECKLIST,JSON.stringify(st)); } catch(e){}
}
function updateChecklistProgress() {
  const total=CHECKLIST_KEYS.length;
  const done=CHECKLIST_KEYS.filter(k=>checklistEl.querySelector(`li[data-key="${k}"]`).classList.contains("cl-done")).length;
  checklistProgress.textContent=`${done} of ${total} Tasks Completed`;
  checklistBarFill.style.width=total>0?`${done/total*100}%`:"0%";
  updateBanner();
}
CHECKLIST_KEYS.forEach(k=>{
  const li=checklistEl.querySelector(`li[data-key="${k}"]`);
  const label=li.querySelector(".cl-item");
  const input=li.querySelector("input[type='checkbox']");
  input.addEventListener("click",e=>e.stopPropagation());
  label.addEventListener("click",e=>{ e.preventDefault(); li.classList.toggle("cl-done"); saveChecklist(); updateChecklistProgress(); });
});
btnResetChecklist.addEventListener("click",()=>{
  openConfirm("Reset Checklist","Reset all checklist items?",()=>{
    CHECKLIST_KEYS.forEach(k=>checklistEl.querySelector(`li[data-key="${k}"]`).classList.remove("cl-done"));
    try{localStorage.removeItem(KEY_CHECKLIST);}catch(e){}
    updateChecklistProgress(); showToast("Checklist reset.");
  });
});

// ─── Sticky note (#12) ───────────────────────────────────────────
stickyNote.value = localStorage.getItem(KEY_NOTE)||"";
let noteTimer=null;
stickyNote.addEventListener("input", ()=>{
  if (noteTimer) clearTimeout(noteTimer);
  noteTimer=setTimeout(()=>{ try{localStorage.setItem(KEY_NOTE,stickyNote.value);}catch(e){} },400);
});
$("btn-clear-note").addEventListener("click",()=>{
  openConfirm("Clear Note","Clear all personal notes?",()=>{
    stickyNote.value=""; try{localStorage.removeItem(KEY_NOTE);}catch(e){}
  });
});

// ─── Filters ─────────────────────────────────────────────────────
searchInput.addEventListener("input",  ()=>{ currentPage=1; renderTable(); });
filterStatus.addEventListener("change",()=>{ currentPage=1; renderTable(); });
filterAssignment.addEventListener("change",()=>{ currentPage=1; renderTable(); });
btnClearFilters.addEventListener("click",()=>{
  searchInput.value=filterStatus.value=filterAssignment.value="";
  currentPage=1; renderTable(); showToast("Filters cleared.");
});

// ─── Export CSV ───────────────────────────────────────────────────
btnExportCsv.addEventListener("click",()=>{
  const filtered=getSorted(getFiltered());
  const date=new Date().toISOString().slice(0,10);
  const filename=`TVET_Student_Report_${date}.csv`;
  const header=["#","Student ID","Student Name","Class","Assignment","Due Date","Status","Remarks","Last Updated"];
  const rows=filtered.map((s,i)=>[
    i+1, s.id, `"${s.name}"`, s.cls, `"${s.assignment}"`,
    s.dueDate||"—", s.status,
    `"${(s.remarks||"").replace(/"/g,'""')}"`,
    s.updatedAt?fmtTs(s.updatedAt):"—"
  ].join(","));
  const csv=[header.join(","),...rows].join("\r\n");
  const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a"); a.href=url; a.download=filename; a.click();
  URL.revokeObjectURL(url);
  showToast(`Exported ${filtered.length} records.`,"success");
});

// ─── Import CSV (#10) ─────────────────────────────────────────────
$("import-csv-input").addEventListener("change", function(e) {
  const file=e.target.files[0]; if (!file) return;
  const reader=new FileReader();
  reader.onload=function(ev) {
    const lines=ev.target.result.split(/\r?\n/).filter(l=>l.trim());
    if (lines.length<2){ showToast("CSV is empty or invalid.","toast-error"); return; }
    // Expect header: Student ID,Student Name,Class,Assignment,Due Date,Status,Remarks
    const header=lines[0].split(",").map(h=>h.trim().toLowerCase().replace(/"/g,""));
    const idxId=header.findIndex(h=>h.includes("id"));
    const idxName=header.findIndex(h=>h.includes("name"));
    const idxCls=header.findIndex(h=>h.includes("class"));
    const idxAssign=header.findIndex(h=>h.includes("assignment"));
    const idxDue=header.findIndex(h=>h.includes("due"));
    const idxStatus=header.findIndex(h=>h.includes("status"));
    const idxRemarks=header.findIndex(h=>h.includes("remark"));
    let added=0, skipped=0;
    pushUndo();
    lines.slice(1).forEach(line=>{
      const cols=line.split(",").map(c=>c.trim().replace(/^"|"$/g,"").replace(/""/g,'"'));
      const id=(cols[idxId]||"").trim();
      const name=(cols[idxName]||"").trim();
      if (!id||!name){ skipped++; return; }
      if (students.find(s=>s.id.toLowerCase()===id.toLowerCase())){ skipped++; return; }
      students.push({
        id, name,
        cls: idxCls>=0 ? (cols[idxCls]||"DVP1A") : "DVP1A",
        assignment: idxAssign>=0 ? (cols[idxAssign]||"") : "",
        dueDate: idxDue>=0 ? (cols[idxDue]||"") : "",
        status: idxStatus>=0 ? (cols[idxStatus]||"Pending") : "Pending",
        remarks: idxRemarks>=0 ? (cols[idxRemarks]||"") : "",
        updatedAt: null
      });
      added++;
    });
    saveStudents(); populateAssignmentFilter(); currentPage=1; refreshAll();
    showToast(`Imported ${added} records. ${skipped} skipped.`, "success");
    this.value="";
  };
  reader.readAsText(file,"UTF-8");
});

// ─── Print ────────────────────────────────────────────────────────
btnPrint.addEventListener("click",()=>window.print());

// ─── Keyboard shortcuts ───────────────────────────────────────────
document.addEventListener("keydown",e=>{
  if ((e.ctrlKey||e.metaKey)&&e.key==="f"){ e.preventDefault(); searchInput.focus(); searchInput.select(); }
  if ((e.ctrlKey||e.metaKey)&&e.key==="e"){ e.preventDefault(); btnExportCsv.click(); }
  if ((e.ctrlKey||e.metaKey)&&e.key==="z"&&undoStack.length){
    e.preventDefault();
    const snap=undoStack.pop();
    if(snap){ students=snap.students; saveStudents(); refreshAll(); showToast("Undone.","success"); }
  }
  if (e.key==="Escape"){
    modalStudent.classList.add("hidden"); modalConfirm.classList.add("hidden"); pendingConfirmCb=null;
  }
});

// ─── Full refresh helper ──────────────────────────────────────────
function refreshAll() {
  updateCards(); updateAssignStats(); renderTable(); updateBanner();
}

// ─── Init ─────────────────────────────────────────────────────────
autoCheckOverdue();
buildColToggles();
applyColVisibility();
populateAssignmentFilter();
refreshAll();
loadChecklist();
